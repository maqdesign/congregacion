# Predicación Pública de la Congregación

Esta es una aplicación web de ejemplo desarrollada con **Flask** y **SQLite** para facilitar la organización de los puestos de predicación pública en una congregación. Fue creada siguiendo las especificaciones proporcionadas por el usuario, con un enfoque en accesibilidad y simplicidad para permitir que personas sin experiencia técnica puedan ponerla en marcha fácilmente.

## Funcionalidades incluidas (MVP)

- **Landing pública** con listado de congregaciones y puestos de predicación, mostrando algunos horarios y cupos.
- **Registro de usuarios** con dos tipos principales de cuenta: **Publicador** y **Superintendente de Servicio**.
- **Inicio y cierre de sesión** con almacenamiento de la sesión en cookies.
- **Estado de cuenta**: los publicadores son creados en estado *pendiente* y deberán ser aprobados por el comité (esta funcionalidad podrá ampliarse en sprints futuros). Los superintendentes se crean en estado *aprobado* por defecto.
- **Panel del publicador** donde se muestran los puestos de su congregación (solo lectura en esta versión).
- **Panel de administración** para superintendentes, coordinadores y secretarios con un listado de puestos y la posibilidad de crear nuevos (solo los superintendentes pueden añadir puestos en esta versión).

La aplicación incluye datos de demostración para que se pueda ver funcionando sin necesidad de configuración adicional:

- Una congregación llamada **“Eugenio María de Hostos”** con tres puestos de predicación y horarios definidos.
- Usuarios de ejemplo para el comité (superintendente, coordinador, secretario) y seis publicadores con distintos estados (aprobado, pendiente, rechazado).

## Requisitos previos

- Python 3.9 o superior.
- pip (gestor de paquetes de Python).

## Instalación

1. Clona este repositorio o descarga los archivos.
2. Ve al directorio de la aplicación:

   ```bash
   cd predicacion_app
   ```

3. Crea un entorno virtual (opcional pero recomendado) e instala las dependencias:

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

4. Ejecuta la aplicación:

   ```bash
   python app.py
   ```

   La aplicación se iniciará en `http://127.0.0.1:5000/`.

## Uso básico

### Registro y acceso

- Accede a la página de **Registro** y rellena tus datos. Los publicadores deberán seleccionar la congregación a la que pertenecen. Los superintendentes no necesitan seleccionar congregación; en sprints futuros se añadirá la gestión completa de congregaciones desde la interfaz.
- Una vez registrado, inicia sesión desde la página de **Entrar**. Si eres publicador y tu cuenta está en estado `pendiente`, verás un aviso indicando que tu cuenta debe ser aprobada. Si eres superintendente, coordinador o secretario, tendrás acceso inmediato al panel de administración.

### Panel del publicador

En el panel del publicador podrás ver los puestos y horarios de la congregación a la que perteneces. En futuras iteraciones se habilitará la inscripción automática a horarios y la solicitud de reservas recurrentes.

### Panel de administración

Este panel está disponible para los roles de superintendente, coordinador y secretario. En esta versión se muestra el listado de puestos de la congregación y se permite al superintendente añadir nuevos puestos. En sprints posteriores se podrán gestionar horarios, aprobar cuentas de publicadores y atender solicitudes recurrentes.

## Próximos pasos

Este repositorio sienta las bases para ir construyendo las funcionalidades descritas en el guion detallado previamente. Algunas de las tareas pendientes que se podrían abordar en iteraciones futuras son:

- Gestión de horarios desde la interfaz de administrador (creación, edición, activación/inactivación).
- Aprobación o rechazo de cuentas de publicadores por parte del comité de servicio.
- Inscripción directa de publicadores a puestos y horarios con control de cupos.
- Solicitudes de inscripciones recurrentes y su aprobación.
- Notificaciones por correo electrónico o SMS para informar de cambios de estado y recordatorios.
- Mejoras en la accesibilidad y la internacionalización.

## Licencia

Esta aplicación de ejemplo se proporciona sin garantía. Eres libre de modificarla y adaptarla según tus necesidades.