"""
Predicación Pública de la Congregación
====================================

Esta aplicación es una implementación simplificada del flujo descrito en la
especificación dada por el usuario. Está escrita con Flask y utiliza
SQLAlchemy como ORM y SQLite como motor de base de datos. El propósito de
esta aplicación es proporcionar una base de código fácilmente extensible
que permita ir añadiendo funcionalidades en iteraciones (sprints), tal y
como se detalló en el guion anterior.

El MVP inicial implementa:

* Listado público de puestos de predicación (por congregación y horarios)
* Registro de usuarios con roles de Publicador o Superintendente
* Inicio de sesión simple y cierre de sesión
* Dashboard básico para Publicadores aprobados que permite visualizar los
  puestos disponibles
* Panel de administración para Superintendentes donde pueden ver y
  gestionar congregaciones y puestos (solo lectura en esta versión)

Para ejecutar la aplicación localmente:

1. Instalar las dependencias:
   ```bash
   pip install -r requirements.txt
   ```

2. Ejecutar la aplicación:
   ```bash
   python app.py
   ```

La aplicación se servirá en http://127.0.0.1:5000/.
"""

import os
from datetime import datetime
from flask import (
    Flask,
    render_template,
    redirect,
    url_for,
    request,
    session,
    flash,
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# Configuración de Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///predicacion.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicialización de la base de datos
db = SQLAlchemy(app)


class Role:
    """Enumeración simple para roles de usuario."""

    PUBLICADOR = 'publicador'
    SUPERINTENDENTE = 'superintendente'
    COORDINADOR = 'coordinador'
    SECRETARIO = 'secretario'

    @classmethod
    def list(cls):
        return [cls.PUBLICADOR, cls.SUPERINTENDENTE, cls.COORDINADOR, cls.SECRETARIO]


class AccountStatus:
    """Enumeración simple para el estado de la cuenta."""

    PENDING = 'pendiente'
    APPROVED = 'aprobado'
    REJECTED = 'rechazado'

    @classmethod
    def list(cls):
        return [cls.PENDING, cls.APPROVED, cls.REJECTED]


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(30), nullable=False, default=Role.PUBLICADOR)
    status = db.Column(db.String(30), nullable=False, default=AccountStatus.PENDING)
    congregation_id = db.Column(db.Integer, db.ForeignKey('congregation.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    congregation = db.relationship('Congregation', back_populates='users')

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def __repr__(self) -> str:
        return f"<User {self.name} ({self.role})>"


class Congregation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    city = db.Column(db.String(100), nullable=True)
    country = db.Column(db.String(100), nullable=True)
    code = db.Column(db.String(50), unique=True, nullable=False)
    tz = db.Column(db.String(50), nullable=False, default='America/Santo_Domingo')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    users = db.relationship('User', back_populates='congregation', cascade='all, delete')
    posts = db.relationship('Post', back_populates='congregation', cascade='all, delete')

    def __repr__(self) -> str:
        return f"<Congregation {self.name}>"


class Post(db.Model):
    """Puestos de predicación pública."""

    id = db.Column(db.Integer, primary_key=True)
    congregation_id = db.Column(db.Integer, db.ForeignKey('congregation.id'), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    address = db.Column(db.String(250), nullable=False)
    notes = db.Column(db.Text, nullable=True)

    congregation = db.relationship('Congregation', back_populates='posts')
    schedules = db.relationship('Schedule', back_populates='post', cascade='all, delete')

    def __repr__(self) -> str:
        return f"<Post {self.name}>"


class Schedule(db.Model):
    """Horarios por puesto. Define día de la semana y franja horaria."""

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=lunes, 6=domingo
    timeslot = db.Column(db.String(20), nullable=False)  # mañana, tarde, noche
    capacity = db.Column(db.Integer, nullable=False, default=2)
    active = db.Column(db.Boolean, default=True)

    post = db.relationship('Post', back_populates='schedules')

    def __repr__(self) -> str:
        return f"<Schedule {self.day_of_week}-{self.timeslot} (cap {self.capacity})>"


def seed_data():
    """Crea datos de ejemplo si la base de datos está vacía."""
    if Congregation.query.count() == 0:
        # Crear congregación de ejemplo
        cong = Congregation(
            name="Eugenio María de Hostos",
            city="Santo Domingo",
            country="República Dominicana",
            code="EMH",
            tz="America/Santo_Domingo",
        )
        db.session.add(cong)
        db.session.commit()

        # Crear puestos y horarios
        puesto1 = Post(
            congregation=cong,
            name="Parque Central",
            address="Av. Bolívar con Máximo Gómez, frente al Parque",
            notes="Esquina muy transitada, bajo sombra de árbol",
        )
        puesto2 = Post(
            congregation=cong,
            name="Plaza Duarte",
            address="Calle Duarte #10",
            notes="Frente al mercado principal",
        )
        puesto3 = Post(
            congregation=cong,
            name="Hospital Central",
            address="Avenida Independencia",
            notes="Entrada principal del hospital",
        )
        db.session.add_all([puesto1, puesto2, puesto3])
        db.session.commit()

        # Crear horarios por puesto
        for post in [puesto1, puesto2, puesto3]:
            for day in range(0, 6):  # de lunes (0) a sábado (5)
                for timeslot in ['mañana', 'tardecita', 'noche']:
                    sched = Schedule(
                        post=post,
                        day_of_week=day,
                        timeslot=timeslot,
                        capacity=2 + (day % 3),  # capacidades variables para ejemplo
                    )
                    db.session.add(sched)
        db.session.commit()

        # Crear usuarios de comité
        # Superintendente de servicio
        super_user = User(
            name="Superintendente Demo",
            phone="1000000001",
            email="super@example.com",
            role=Role.SUPERINTENDENTE,
            status=AccountStatus.APPROVED,
            congregation=cong,
        )
        super_user.set_password("demo123")
        # Coordinador
        coord = User(
            name="Coordinador Demo",
            phone="1000000002",
            email="coord@example.com",
            role=Role.COORDINADOR,
            status=AccountStatus.APPROVED,
            congregation=cong,
        )
        coord.set_password("demo123")
        # Secretario
        secre = User(
            name="Secretario Demo",
            phone="1000000003",
            email="secre@example.com",
            role=Role.SECRETARIO,
            status=AccountStatus.APPROVED,
            congregation=cong,
        )
        secre.set_password("demo123")

        # Publicadores (2 aprobados, 2 pendientes, 2 rechazados)
        publicadores = []
        for i, status in enumerate([
            AccountStatus.APPROVED,
            AccountStatus.APPROVED,
            AccountStatus.PENDING,
            AccountStatus.PENDING,
            AccountStatus.REJECTED,
            AccountStatus.REJECTED,
        ], start=1):
            u = User(
                name=f"Publicador {i}",
                phone=f"200000000{i}",
                email=f"pub{i}@example.com",
                role=Role.PUBLICADOR,
                status=status,
                congregation=cong,
            )
            u.set_password("demo123")
            publicadores.append(u)
        db.session.add_all([super_user, coord, secre] + publicadores)
        db.session.commit()


@app.before_first_request
def initialize_database():
    """Crea las tablas de base de datos y datos de ejemplo al iniciar la app."""
    db.create_all()
    seed_data()


@app.context_processor
def inject_now():
    """Inserta variables comunes en todas las plantillas."""
    return {'current_year': datetime.utcnow().year}


def current_user():
    """Devuelve el usuario actualmente autenticado o None."""
    user_id = session.get('user_id')
    if user_id:
        return User.query.get(user_id)
    return None


def login_required(role=None):
    """Decorador para requerir inicio de sesión y, opcionalmente, un rol específico."""

    def decorator(func):
        from functools import wraps

        @wraps(func)
        def wrapper(*args, **kwargs):
            user = current_user()
            if not user:
                flash('Debes iniciar sesión para acceder a esta página.', 'warning')
                return redirect(url_for('login', next=request.endpoint))
            if role and user.role != role:
                flash('No tienes permisos para acceder a esta página.', 'warning')
                return redirect(url_for('index'))
            return func(*args, **kwargs)

        return wrapper

    return decorator


@app.route('/')
def index():
    """Página de inicio: lista pública de puestos."""
    congregations = Congregation.query.all()
    return render_template('index.html', congregations=congregations, user=current_user())


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Formulario de registro de usuario."""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        email = request.form.get('email', '').strip() or None
        password = request.form.get('password', '').strip()
        role = request.form.get('role')
        congregation_id = request.form.get('congregation_id') or None

        # Validaciones básicas
        if not name or not phone or not password or role not in Role.list():
            flash('Por favor completa todos los campos obligatorios.', 'danger')
            return redirect(url_for('register'))
        if User.query.filter_by(phone=phone).first():
            flash('El número de teléfono ya está registrado.', 'danger')
            return redirect(url_for('register'))
        if email and User.query.filter_by(email=email).first():
            flash('El email ya está registrado.', 'danger')
            return redirect(url_for('register'))

        # Crear usuario
        user = User(
            name=name,
            phone=phone,
            email=email,
            role=role,
            status=AccountStatus.APPROVED if role != Role.PUBLICADOR else AccountStatus.PENDING,
        )
        user.set_password(password)
        # Asociar congregación si es publicador
        if role == Role.PUBLICADOR and congregation_id:
            user.congregation_id = int(congregation_id)
        db.session.add(user)
        db.session.commit()
        flash('Registro exitoso. Por favor inicia sesión.', 'success')
        return redirect(url_for('login'))

    # GET
    congregations = Congregation.query.all()
    return render_template('register.html', congregations=congregations, user=current_user())


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Inicio de sesión."""
    if request.method == 'POST':
        phone_or_email = request.form.get('identifier', '').strip()
        password = request.form.get('password', '').strip()

        user = User.query.filter((User.phone == phone_or_email) | (User.email == phone_or_email)).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            flash('Has iniciado sesión correctamente.', 'success')
            # Redirigir a la página que se intentaba acceder
            next_endpoint = request.args.get('next')
            if next_endpoint and next_endpoint != 'logout':
                return redirect(url_for(next_endpoint))
            return redirect(url_for('index'))
        flash('Credenciales inválidas.', 'danger')
        return redirect(url_for('login'))
    return render_template('login.html', user=current_user())


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Has cerrado sesión.', 'info')
    return redirect(url_for('index'))


@app.route('/dashboard')
@login_required()
def dashboard():
    """Panel para publicadores y superintendentes."""
    user = current_user()
    if user.role == Role.PUBLICADOR:
        # Solo publicadores aprobados ven dashboard
        if user.status != AccountStatus.APPROVED:
            flash('Tu cuenta todavía no ha sido aprobada.', 'warning')
            return redirect(url_for('index'))
        congregation = user.congregation
        posts = congregation.posts if congregation else []
        return render_template('dashboard.html', user=user, posts=posts)
    else:
        # Superintendentes, coordinadores y secretarios
        return redirect(url_for('admin'))


@app.route('/admin', methods=['GET', 'POST'])
@login_required()
def admin():
    """Panel de administración para superintendentes de servicio y roles del comité."""
    user = current_user()
    if user.role not in [Role.SUPERINTENDENTE, Role.COORDINADOR, Role.SECRETARIO]:
        flash('No tienes permisos para acceder al panel de administración.', 'danger')
        return redirect(url_for('index'))

    congregation = user.congregation
    if not congregation:
        flash('No tienes una congregación asociada. Contacta al administrador.', 'danger')
        return redirect(url_for('index'))

    # Manejo de creación de nuevos puestos (solo superintendentes)
    if request.method == 'POST' and user.role == Role.SUPERINTENDENTE:
        name = request.form.get('name', '').strip()
        address = request.form.get('address', '').strip()
        notes = request.form.get('notes', '').strip()
        if name and address:
            post = Post(congregation=congregation, name=name, address=address, notes=notes)
            db.session.add(post)
            db.session.commit()
            flash('Puesto creado correctamente.', 'success')
            return redirect(url_for('admin'))
        flash('Debes completar nombre y dirección del puesto.', 'danger')

    posts = congregation.posts
    return render_template('admin.html', user=user, congregation=congregation, posts=posts)


if __name__ == '__main__':
    app.run(debug=True)